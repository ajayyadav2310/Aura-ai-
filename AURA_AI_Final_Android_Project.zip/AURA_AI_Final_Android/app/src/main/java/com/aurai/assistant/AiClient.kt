package com.aurai.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AiResult(val text: String, val rateLimited: Boolean = false, val warning: String? = null)

class AiClient(private val keys: SecureKeyStore) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS)
        .callTimeout(70, TimeUnit.SECONDS).build()

    suspend fun reply(provider: String, prompt: String, history: List<ChatMessage>, memory: String): AiResult =
        withContext(Dispatchers.IO) {
            val key = keys.get(provider) ?: return@withContext AiResult("Settings → Connections mein pehle $provider API key add karein.")
            try {
                val requestData = makeRequest(provider, key, prompt, history, memory)
                val request = Request.Builder().url(requestData.first)
                    .post(requestData.second.toRequestBody("application/json".toMediaType()))
                    .apply { requestData.third.forEach { (name, value) -> header(name, value) } }
                    .build()
                http.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (response.code == 429 || body.contains("rate_limit", true) || body.contains("quota exceeded", true)) {
                        return@withContext AiResult("Provider limit reached: $provider", true, "Provider limit reached. Aap kisi doosre configured provider par switch kar sakte hain.")
                    }
                    if (!response.isSuccessful) {
                        return@withContext AiResult("$provider error ${response.code}: ${body.take(280)}",
                            warning = if (response.code in 400..499) "API request check karein. Key, billing aur model availability verify karein." else null)
                    }
                    AiResult(parse(provider, body))
                }
            } catch (e: Exception) {
                AiResult("Network error: ${e.localizedMessage ?: "Please try again."}")
            }
        }

    private fun makeRequest(
        provider: String, key: String, prompt: String, history: List<ChatMessage>, memory: String
    ): Triple<String, String, Map<String, String>> {
        val systemText = buildString {
            append("You are AURA, a helpful personal assistant. Be clear, friendly and concise. ")
            append("Reply in the user's language. ")
            if (memory.isNotBlank()) append("User-approved memory: $memory ")
        }
        if (provider == "Gemini") {
            val contents = JSONArray()
            val prior = history.takeLast(10)
            prior.forEach { msg ->
                if (msg.text.isNotBlank()) contents.put(
                    JSONObject().put("role", if (msg.role == "AURA") "model" else "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
                )
            }
            contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt))))
            val json = JSONObject().put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemText))))
                .put("contents", contents)
            return Triple(
                "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$key",
                json.toString(), emptyMap()
            )
        }
        val endpoint = when (provider) {
            "Groq" -> "https://api.groq.com/openai/v1/chat/completions"
            "OpenAI" -> "https://api.openai.com/v1/chat/completions"
            "DeepSeek" -> "https://api.deepseek.com/chat/completions"
            else -> "https://openrouter.ai/api/v1/chat/completions"
        }
        val model = when (provider) {
            "Groq" -> "llama-3.3-70b-versatile"
            "OpenAI" -> "gpt-4o-mini"
            "DeepSeek" -> "deepseek-chat"
            else -> "openai/gpt-4o-mini"
        }
        val messages = JSONArray().put(JSONObject().put("role", "system").put("content", systemText))
        history.takeLast(10).forEach {
            messages.put(JSONObject().put("role", if (it.role == "AURA") "assistant" else "user").put("content", it.text))
        }
        messages.put(JSONObject().put("role", "user").put("content", prompt))
        val headers = mutableMapOf("Authorization" to "Bearer $key")
        if (provider == "OpenRouter") {
            headers["HTTP-Referer"] = "https://aura-ai.app"
            headers["X-Title"] = "AURA AI"
        }
        return Triple(endpoint, JSONObject().put("model", model).put("messages", messages).toString(), headers)
    }

    private fun parse(provider: String, raw: String): String = try {
        val json = JSONObject(raw)
        if (provider == "Gemini") json.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        else json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    } catch (_: Exception) { "AI response read nahi ho paya. Please try again." }
}
