package com.aurai.assistant

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class SecureKeyStore(context: Context) {
    private val prefs = context.getSharedPreferences("aura_secure_keys", Context.MODE_PRIVATE)
    private val alias = "AURA_AES_GCM_KEY"

    private fun secretKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true).build()
        )
        return generator.generateKey()
    }

    fun put(provider: String, value: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val packed = cipher.iv + cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        prefs.edit().putString("key_$provider", Base64.encodeToString(packed, Base64.NO_WRAP)).apply()
    }

    fun get(provider: String): String? = runCatching {
        val packed = Base64.decode(prefs.getString("key_$provider", null) ?: return null, Base64.NO_WRAP)
        val iv = packed.copyOfRange(0, 12)
        val encrypted = packed.copyOfRange(12, packed.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
        String(cipher.doFinal(encrypted), Charsets.UTF_8)
    }.getOrNull()

    fun remove(provider: String) { prefs.edit().remove("key_$provider").apply() }
    fun configured() = PROVIDERS.filter { !get(it).isNullOrBlank() }
    fun selected() = prefs.getString("selected_provider", "Gemini") ?: "Gemini"
    fun setSelected(provider: String) { prefs.edit().putString("selected_provider", provider).apply() }

    companion object {
        val PROVIDERS = listOf("Gemini", "Groq", "OpenAI", "DeepSeek", "OpenRouter")
        val KEY_URLS = mapOf(
            "Gemini" to "https://aistudio.google.com/app/apikey",
            "Groq" to "https://console.groq.com/keys",
            "OpenAI" to "https://platform.openai.com/api-keys",
            "DeepSeek" to "https://platform.deepseek.com/api_keys",
            "OpenRouter" to "https://openrouter.ai/keys"
        )
    }
}
