package com.aurai.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ChatMessage(val role: String, val text: String, val time: Long = System.currentTimeMillis())

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("aura_local_data", Context.MODE_PRIVATE)

    fun messages(): List<ChatMessage> = runCatching {
        val array = JSONArray(prefs.getString("chat", "[]"))
        (0 until array.length()).map { i ->
            val item = array.getJSONObject(i)
            ChatMessage(item.optString("role"), item.optString("text"), item.optLong("time"))
        }
    }.getOrDefault(emptyList())

    fun saveMessages(items: List<ChatMessage>) {
        val array = JSONArray()
        items.takeLast(400).forEach {
            array.put(JSONObject().put("role", it.role).put("text", it.text).put("time", it.time))
        }
        prefs.edit().putString("chat", array.toString()).apply()
    }

    fun getString(key: String, fallback: String = "") = prefs.getString(key, fallback) ?: fallback
    fun setString(key: String, value: String) { prefs.edit().putString(key, value).apply() }

    fun notes(): List<String> = getString("notes").split("\n").filter { it.isNotBlank() }
    fun saveNotes(notes: List<String>) { setString("notes", notes.joinToString("\n")) }

    fun memory(): String = getString("memory")
    fun setMemory(value: String) = setString("memory", value)
}
