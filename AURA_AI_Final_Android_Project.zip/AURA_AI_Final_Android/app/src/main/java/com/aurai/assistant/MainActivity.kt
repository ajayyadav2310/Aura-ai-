package com.aurai.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import java.util.Locale

private val BG = Color(0xFF080612)
private val PANEL = Color(0xFF171027)
private val PANEL2 = Color(0xFF211438)
private val PURPLE = Color(0xFFB45CFF)
private val LAVENDER = Color(0xFFD7AEFF)
private val MUTED = Color(0xFFAA9ABF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val keys = SecureKeyStore(this)
        val store = LocalStore(this)
        setContent { AuraApp(this, keys, store) }
    }
}

@Composable
private fun AuraApp(activity: MainActivity, keys: SecureKeyStore, store: LocalStore) {
    var page by remember { mutableStateOf("Home") }
    var provider by remember { mutableStateOf(keys.selected()) }
    var messages by remember { mutableStateOf(store.messages()) }
    var prompt by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }
    var switchPrompt by remember { mutableStateOf<String?>(null) }
    var pendingAction by remember { mutableStateOf<ProposedAction?>(null) }
    val scope = rememberCoroutineScope()
    val tts = remember { mutableStateOf<TextToSpeech?>(null) }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            prompt = spoken
            page = "Chat"
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = BG, surface = PANEL, primary = PURPLE, onBackground = Color.White, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = BG) {
            Column(Modifier.fillMaxSize()) {
                Header(onMenu = { page = "Menu" }, onSettings = { page = "Settings" })
                Box(Modifier.weight(1f)) {
                    when (page) {
                        "Home" -> HomeScreen(
                            input = prompt, onInput = { prompt = it },
                            onSend = { submitPrompt(prompt, activity, keys, store, messages, { messages = it }, { prompt = it }, { busy = it }, { switchPrompt = it }, { notice = it }, scope, provider) { page = "Chat" } },
                            onVoice = { page = "Voice" },
                            onControl = { page = "Phone Control" }
                        )
                        "Chat" -> ChatScreen(messages, prompt, { prompt = it }, busy, onSend = {
                            submitPrompt(prompt, activity, keys, store, messages, { messages = it }, { prompt = it }, { busy = it }, { switchPrompt = it }, { notice = it }, scope, provider) { }
                        })
                        "Voice" -> VoiceScreen(activity, onBack = { page = "Home" }, onRecognized = { prompt = it; page = "Chat" })
                        "Settings" -> SettingsScreen(keys, provider, { provider = it; keys.setSelected(it) }, store)
                        "Personality" -> PersonalityScreen(store)
                        "Memory" -> MemoryScreen(store)
                        "Notes" -> NotesScreen(store)
                        "Phone Control" -> PhoneControlScreen(activity) { pendingAction = it }
                        "Menu" -> MenuScreen { page = it }
                        "History" -> ChatScreen(messages, prompt, { prompt = it }, busy, onSend = { page = "Chat" })
                        else -> MenuScreen { page = it }
                    }
                }
                BottomBar(page) { page = it }
            }

            switchPrompt?.let { retryText ->
                AlertDialog(
                    onDismissRequest = { switchPrompt = null },
                    title = { Text("API limit reached") },
                    text = { Text("$provider limit/rate error mila. Kya configured alternate provider par switch karke isi message ko retry karein?") },
                    confirmButton = {
                        TextButton(onClick = {
                            val next = keys.configured().firstOrNull { it != provider }
                            switchPrompt = null
                            if (next == null) notice = "Switch karne ke liye Settings → Connections mein ek aur API key add karein."
                            else {
                                provider = next; keys.setSelected(next)
                                submitPrompt(retryText, activity, keys, store, messages, { messages = it }, { prompt = it }, { busy = it }, { switchPrompt = it }, { notice = it }, scope, provider) {}
                            }
                        }) { Text("Switch & retry") }
                    },
                    dismissButton = { TextButton(onClick = { switchPrompt = null }) { Text("Not now") } }
                )
            }
            pendingAction?.let { action ->
                AlertDialog(
                    onDismissRequest = { pendingAction = null },
                    title = { Text(action.title) },
                    text = { Text(action.description + "\n\nAURA action perform kare?") },
                    confirmButton = {
                        TextButton(onClick = {
                            pendingAction = null
                            runCatching { action.execute() }.onFailure { notice = "Action launch nahi ho paya: ${it.localizedMessage}" }
                        }) { Text("Confirm") }
                    },
                    dismissButton = { TextButton(onClick = { pendingAction = null }) { Text("Cancel") } }
                )
            }
            notice?.let { msg ->
                AlertDialog(onDismissRequest = { notice = null }, title = { Text("AURA AI") }, text = { Text(msg) },
                    confirmButton = { TextButton(onClick = { notice = null }) { Text("OK") } })
            }
        }
    }
}

private fun submitPrompt(
    raw: String, activity: MainActivity, keys: SecureKeyStore, store: LocalStore,
    current: List<ChatMessage>, setMessages: (List<ChatMessage>) -> Unit,
    setPrompt: (String) -> Unit, setBusy: (Boolean) -> Unit,
    setSwitchPrompt: (String?) -> Unit, setNotice: (String?) -> Unit,
    scope: kotlinx.coroutines.CoroutineScope, provider: String, after: () -> Unit
) {
    val text = raw.trim()
    if (text.isEmpty()) return
    val action = PhoneActions.prepare(activity, text)
    if (action != null) {
        setNotice("Phone action detected. Open Phone Control to review and confirm it.")
        return
    }
    val updated = current + ChatMessage("You", text)
    setMessages(updated); store.saveMessages(updated); setPrompt(""); setBusy(true); after()
    scope.launch {
        val personaContext = "Assistant name: ${store.getString("assistant_name", "AURA")}. Style: ${store.getString("personality", "Friendly")}. " + store.memory()\n        val result = AiClient(keys).reply(provider, text, updated.dropLast(1), personaContext)
        if (result.rateLimited) {
            setSwitchPrompt(text)
        } else {
            val next = updated + ChatMessage("AURA", result.text)
            setMessages(next); store.saveMessages(next)
            result.warning?.let(setNotice)
        }
        setBusy(false)
    }
}

@Composable
private fun Header(onMenu: () -> Unit, onSettings: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, null, tint = LAVENDER) }
        Text("A U R A   A I", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, null, tint = LAVENDER) }
    }
}

@Composable
private fun HomeScreen(input: String, onInput: (String) -> Unit, onSend: () -> Unit, onVoice: () -> Unit, onControl: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(14.dp))
        Text("YOUR PERSONAL AI ASSISTANT", color = MUTED, fontSize = 9.sp, letterSpacing = 3.sp)
        AuraOrb(Modifier.size(270.dp))
        Text("Hello, I'm AURA", color = LAVENDER, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Text("Always here for you", color = MUTED, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        Button(onClick = onVoice, shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = PANEL2)) {
            Icon(Icons.Default.Mic, null, tint = LAVENDER); Spacer(Modifier.width(8.dp)); Text("Tap to Talk")
        }
        Spacer(Modifier.height(18.dp))
        PromptBar(input, onInput, onSend)
        Spacer(Modifier.height(16.dp))
        Text("✦  Ask anything. Do anything.", color = LAVENDER, fontWeight = FontWeight.SemiBold)
        Text("Chat, speak or control your phone — from one assistant.", color = MUTED, fontSize = 11.sp)
        Spacer(Modifier.height(14.dp))
        TextButton(onClick = onControl) { Text("Open Phone Control  →", color = LAVENDER) }
    }
}

@Composable
private fun AuraOrb(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "auraOrb")
    val pulse by transition.animateFloat(0.94f, 1.04f, infiniteRepeatable(tween(2300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    Canvas(modifier) {
        val c = center
        val r = size.minDimension * .37f * pulse
        drawCircle(Brush.radialGradient(listOf(Color(0xFFF2D9FF), Color(0xFFC15AFF), Color(0xFF7421B6), Color(0xFF160822))), r, c)
        drawCircle(Color(0xFFDDA5FF).copy(alpha = .28f), r * 1.22f, c, style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
        drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = .65f), Color.Transparent)), r * .22f, androidx.compose.ui.geometry.Offset(c.x - r*.38f, c.y - r*.40f))
        drawCircle(Brush.radialGradient(listOf(Color(0xFFE2B6FF), Color(0xFF8A32CF), Color(0xFF310A55))), r*.53f, androidx.compose.ui.geometry.Offset(c.x, c.y+r*.52f))
        drawCircle(Color.White.copy(alpha=.85f), r*.06f, androidx.compose.ui.geometry.Offset(c.x,c.y+r*.52f))
    }
}

@Composable
private fun PromptBar(value: String, onValue: (String) -> Unit, onSend: () -> Unit) {
    Row(Modifier.fillMaxWidth().border(1.dp, Color(0xFF593775), RoundedCornerShape(28.dp)).background(PANEL, RoundedCornerShape(28.dp)).padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("✦", color = LAVENDER, fontSize = 22.sp, modifier = Modifier.padding(horizontal = 8.dp))
        BasicTextField(value, onValue, Modifier.weight(1f), singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
            decorationBox = { inner -> Box { if (value.isEmpty()) Text("Ask me anything...", color = MUTED); inner() } })
        IconButton(onClick = onSend, modifier = Modifier.background(PURPLE, CircleShape).size(44.dp)) {
            Icon(Icons.Default.Send, null, tint = Color.White)
        }
    }
}

@Composable
private fun ChatScreen(messages: List<ChatMessage>, input: String, onInput: (String) -> Unit, busy: Boolean, onSend: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Chat with AURA", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Local chat history • Your selected AI provider", color = MUTED, fontSize = 11.sp)
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(messages) { msg ->
                Column(Modifier.fillMaxWidth().background(if (msg.role == "You") PANEL2 else PANEL, RoundedCornerShape(16.dp)).padding(13.dp)) {
                    Text(msg.role, color = LAVENDER, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp)); Text(msg.text, color = Color.White, fontSize = 14.sp)
                }
            }
            if (busy) item { Text("AURA is thinking…", color = MUTED) }
        }
        PromptBar(input, onInput, onSend)
    }
}

@Composable
private fun VoiceScreen(activity: MainActivity, onBack: () -> Unit, onRecognized: (String) -> Unit) {
    var recognized by remember { mutableStateOf("Tap the microphone and speak.") }
    var ttsReady by remember { mutableStateOf(false) }
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        recognized = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: "Speech not detected."
        if (recognized != "Speech not detected.") onRecognized(recognized)
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("AURA Voice", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        AuraOrb(Modifier.size(220.dp))
        Text(recognized, color = LAVENDER)
        Spacer(Modifier.height(14.dp))
        Button(onClick = {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to AURA")
            }
            runCatching { speech.launch(intent) }.onFailure { recognized = "Speech recognition is not available." }
        }) { Icon(Icons.Default.Mic, null); Spacer(Modifier.width(8.dp)); Text("Start listening") }
        Button(onClick = {
            val service = Intent(activity, AssistantForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= 26) activity.startForegroundService(service) else activity.startService(service)
            recognized = "Background assistant notification started. This does not enable always-on wake-word listening."
        }, colors = ButtonDefaults.buttonColors(containerColor = PANEL2)) { Text("Enable background service") }
        OutlinedButton(onClick = { activity.stopService(Intent(activity, AssistantForegroundService::class.java)); recognized = "Background service stopped." }) { Text("Stop background service") }
        TextButton(onClick = onBack) { Text("Back to Home") }
        Text("Voice input uses Android speech recognition. Background service displays a persistent notification; wake-word listening needs a separate always-on speech engine.", color = MUTED, fontSize = 10.sp)
    }
}

@Composable
private fun SettingsScreen(keys: SecureKeyStore, selected: String, onSelected: (String) -> Unit, store: LocalStore) {
    var active by remember { mutableStateOf("Gemini") }
    var keyText by remember { mutableStateOf("") }
    var reveal by remember { mutableStateOf(false) }
    var connected by remember { mutableStateOf(keys.configured()) }
    val context = androidx.compose.ui.platform.LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("Connections", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Har user apni API key use karta hai. Login nahi chahiye.", color = MUTED, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        SecureKeyStore.PROVIDERS.forEach { name ->
            Column(Modifier.fillMaxWidth().padding(bottom = 12.dp).border(1.dp, Color(0xFF55366F), RoundedCornerShape(20.dp)).background(PANEL, RoundedCornerShape(20.dp)).padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(name, color = Color.White, fontWeight = FontWeight.Bold)
                        Text(if (name in connected) "Connected • key saved on this phone" else "Not connected", color = if (name in connected) Color(0xFF8DE5B2) else MUTED, fontSize = 10.sp)
                    }
                    TextButton(onClick = { active = name; keyText = "" }) { Text("Add / edit", color = LAVENDER) }
                }
                if (active == name) {
                    OutlinedTextField(keyText, { keyText = it }, Modifier.fillMaxWidth(), label = { Text("Paste $name API key") }, singleLine = true,
                        visualTransformation = if (reveal) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        trailingIcon = { IconButton(onClick = { reveal = !reveal }) { Icon(if (reveal) Icons.Default.VisibilityOff else Icons.Default.Visibility, null) } })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = {
                            if (keyText.isNotBlank()) {
                                keys.put(name, keyText.trim()); connected = keys.configured(); keyText = ""
                            }
                        }) { Text("Save key") }
                        TextButton(onClick = { onSelected(name) }) { Text(if (selected == name) "Selected ✓" else "Use this AI") }
                    }
                    TextButton(onClick = {
                        val uri = android.net.Uri.parse(SecureKeyStore.KEY_URLS[name])
                        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                    }) { Text("Get $name API key ↗", color = LAVENDER) }
                    TextButton(onClick = { keys.remove(name); connected = keys.configured() }) { Text("Remove key", color = Color(0xFFFF9A9A)) }
                }
            }
        }
        Text("API keys Android Keystore AES-GCM se encrypt hoti hain. Keys ko share mat karein.", color = MUTED, fontSize = 10.sp)
        Spacer(Modifier.height(16.dp))
        Text("Local assistant data", color = Color.White, fontWeight = FontWeight.Bold)
        Text("Chat, notes, memory aur personality is phone par store hote hain.", color = MUTED, fontSize = 11.sp)
        Spacer(Modifier.height(12.dp))
        Text("Selected provider: $selected", color = LAVENDER)
    }
}

@Composable
private fun PersonalityScreen(store: LocalStore) {
    var name by remember { mutableStateOf(store.getString("assistant_name", "AURA")) }
    var style by remember { mutableStateOf(store.getString("personality", "Friendly")) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("Assistant personality", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(name, { name = it; store.setString("assistant_name", it) }, Modifier.fillMaxWidth(), label = { Text("Assistant name") })
        Spacer(Modifier.height(12.dp))
        Text("Conversation style", color = LAVENDER)
        listOf("Friendly", "Professional", "Funny", "Calm", "Direct").forEach { option ->
            Row(Modifier.fillMaxWidth().clickable { style = option; store.setString("personality", option) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                RadioButton(style == option, onClick = { style = option; store.setString("personality", option) })
                Text(option, color = Color.White)
            }
        }
        Text("Changes are stored locally. The AI prompt can use these preferences in the next refinement.", color = MUTED, fontSize = 10.sp)
    }
}

@Composable
private fun MemoryScreen(store: LocalStore) {
    var memory by remember { mutableStateOf(store.memory()) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Memory", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Only save information you want AURA to remember.", color = MUTED, fontSize = 11.sp)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(memory, { memory = it }, Modifier.fillMaxWidth().weight(1f), label = { Text("Your saved preferences and context") })
        Button(onClick = { store.setMemory(memory) }, Modifier.fillMaxWidth()) { Text("Save memory") }
    }
}

@Composable
private fun NotesScreen(store: LocalStore) {
    var notes by remember { mutableStateOf(store.notes().joinToString("\n")) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Offline Notes", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Notes are saved on this phone.", color = MUTED, fontSize = 11.sp)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(notes, { notes = it }, Modifier.fillMaxWidth().weight(1f), label = { Text("Write your notes here") })
        Button(onClick = { store.saveNotes(notes.lines()) }, Modifier.fillMaxWidth()) { Text("Save notes") }
    }
}

@Composable
private fun PhoneControlScreen(activity: MainActivity, onPrepared: (ProposedAction) -> Unit) {
    var command by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("Phone Control", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Commands are prepared first. AURA asks for confirmation before opening the target app/action.", color = MUTED, fontSize = 11.sp)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(command, { command = it }, Modifier.fillMaxWidth(), label = { Text("Example: open YouTube / call 9876543210 / alarm 07:00") })
        Button(onClick = {
            val action = PhoneActions.prepare(activity, command)
            if (action != null) onPrepared(action)
        }, Modifier.fillMaxWidth()) { Text("Review action") }
        Spacer(Modifier.height(16.dp))
        listOf("open YouTube", "call 9876543210", "whatsapp Hello, I am on my way", "alarm 07:00").forEach {
            Text("• $it", color = LAVENDER, modifier = Modifier.padding(vertical = 5.dp))
        }
        Text("WhatsApp/SMS actions open a compose/share screen; the user sends the message in the target app. AURA does not silently send messages.", color = MUTED, fontSize = 10.sp)
    }
}

@Composable
private fun MenuScreen(onNavigate: (String) -> Unit) {
    val items = listOf(
        "Chat" to "Talk to your connected AI",
        "Voice" to "Speech recognition and background service",
        "Phone Control" to "Apps, calls, messages and alarms",
        "Personality" to "Change assistant name and style",
        "Memory" to "Edit saved local memory",
        "Notes" to "Offline notes",
        "History" to "Previous conversations",
        "Settings" to "API connections and privacy"
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("AURA Menu", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        items.forEach { (title, subtitle) ->
            Column(Modifier.fillMaxWidth().padding(vertical = 5.dp).border(1.dp, Color(0xFF4C3164), RoundedCornerShape(16.dp)).background(PANEL, RoundedCornerShape(16.dp)).clickable { onNavigate(title) }.padding(15.dp)) {
                Text(title, color = LAVENDER, fontWeight = FontWeight.Bold)
                Text(subtitle, color = MUTED, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun BottomBar(page: String, navigate: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF10091D)).padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
        listOf("Home" to Icons.Default.Home, "Chat" to Icons.Default.ChatBubbleOutline, "Voice" to Icons.Default.Mic, "History" to Icons.Default.History, "Settings" to Icons.Default.Settings).forEach { (name, icon) ->
            Column(Modifier.weight(1f).clickable { navigate(name) }.padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(icon, null, tint = if (page == name) LAVENDER else MUTED, modifier = Modifier.size(22.dp))
                Text(name, color = if (page == name) LAVENDER else MUTED, fontSize = 9.sp)
            }
        }
    }
}
