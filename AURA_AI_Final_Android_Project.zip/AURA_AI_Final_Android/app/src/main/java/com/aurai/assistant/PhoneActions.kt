package com.aurai.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock

data class ProposedAction(val title: String, val description: String, val execute: () -> Unit)

object PhoneActions {
    fun prepare(context: Context, instruction: String): ProposedAction? {
        val text = instruction.trim()
        val lower = text.lowercase()
        if (lower.startsWith("open ") || lower.startsWith("launch ")) {
            val app = text.substringAfter(" ").trim()
            return ProposedAction("Open app", "AURA will try to open: $app") {
                val pm = context.packageManager
                val match = pm.getInstalledApplications(0).firstOrNull {
                    pm.getApplicationLabel(it).toString().equals(app, true)
                }
                val launch = match?.let { pm.getLaunchIntentForPackage(it.packageName) }
                if (launch != null) context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                else context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=$app")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        if (lower.startsWith("call ")) {
            val number = text.substringAfter("call ").trim()
            return ProposedAction("Call number", "Open the phone dialer with: $number") {
                context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        if (lower.startsWith("message ") || lower.startsWith("sms ")) {
            val body = text.substringAfter(" ").trim()
            return ProposedAction("Prepare SMS", "Open SMS app with this message: $body") {
                context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")).putExtra("sms_body", body).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        if (lower.startsWith("whatsapp ")) {
            val body = text.substringAfter("whatsapp ").trim()
            return ProposedAction("Prepare WhatsApp message", "Open WhatsApp share sheet with: $body") {
                val intent = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, body)
                    .setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }
        }
        if (lower.startsWith("alarm ")) {
            val time = text.substringAfter("alarm ").trim().split(":")
            val hour = time.getOrNull(0)?.toIntOrNull()
            val minute = time.getOrNull(1)?.toIntOrNull()
            if (hour != null && minute != null && hour in 0..23 && minute in 0..59) {
                return ProposedAction("Set alarm", "Set an alarm for %02d:%02d".format(hour, minute)) {
                    context.startActivity(Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, hour).putExtra(AlarmClock.EXTRA_MINUTES, minute)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, false).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }
        return null
    }
}
