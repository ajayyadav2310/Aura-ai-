# AURA AI — Final Android Source Project

A native Android (Kotlin + Jetpack Compose) personal assistant foundation. No login or Firebase account is required.

## Included
- Premium dark-purple UI, animated AURA orb, custom adaptive A✦ launcher icon.
- Home, Chat, Voice, History, Settings, Menu, Personality, Memory, Notes and Phone Control screens.
- Bring-your-own-key support: Gemini, Groq, OpenAI, DeepSeek and OpenRouter.
- API keys encrypted locally using Android Keystore AES-GCM.
- Real text chat requests, recent conversation context and user-saved memory prompt.
- Local chat history, notes, memory and personality preferences.
- Android speech-recognition activity (Hindi-first language hint).
- Background foreground-service notification with start/stop controls.
- Permission/confirmation dialog before launching prepared phone actions.
- Open app, dialer, SMS compose, WhatsApp share/compose, and alarm intents.
- Provider switching confirmation after a detected rate-limit response.
- No sign-in, no Firebase dependency, no cloud account required.

## Build requirements
- Android Studio or AndroidIDE with Gradle support.
- JDK 17.
- Android SDK Platform 35 and Build Tools installed.
- Internet for Gradle dependency resolution and API requests.

## Build steps
1. Extract `AURA_AI_Final_Android_Project.zip`.
2. Open the extracted `AURA_AI_Final_Android` folder as an existing Gradle project.
3. Wait for Gradle sync.
4. Build > Build APK(s), then install the debug APK on your phone.

Application ID: `com.aurai.assistant`

## Honest implementation status / platform constraints
- This is a complete source project milestone, not a prebuilt or device-tested APK. It has not been compiled in this environment.
- API model identifiers and provider access can change; if a provider retires a model, update its model ID in `AiClient.kt`.
- Provider usage quota warnings before the limit are not universally available from provider APIs. This build detects rate-limit/quota responses and asks permission to switch after a limit error; provider dashboards show usage.
- Background service currently provides a visible persistent notification. It does not continuously record audio or implement a wake word; it therefore does not run a microphone foreground-service type. Android requires explicit microphone permission, foreground-service restrictions, notification disclosure, and a dedicated wake-word engine for always-on activation.
- Voice uses Android's installed speech recognizer; offline speech availability depends on the device's installed language packs.
- Phone actions require user review. Calls open the dialer; SMS and WhatsApp open compose/share UI so the user completes sending. No silent message sending or accessibility-based UI automation is included.
- App launch works when Android can resolve the installed app label. Some system apps or OEM launchers may behave differently.
- Offline support covers local chat archive, notes, memory, settings and basic UI. Full offline generative AI needs a compatible on-device model/runtime and model files, which are not bundled.
- API keys are encrypted at rest, but any key used by a client app is accessible to the app process and may be exposed on a compromised/rooted device. Use provider spending limits and revoke leaked keys.
- Exact alarm permissions and microphone/notification permission flows may require additional OEM-specific handling before public release.
